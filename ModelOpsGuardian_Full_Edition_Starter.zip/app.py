import streamlit as st
import pandas as pd
from pathlib import Path
from modules.pipeline import run_experiment, load_registry, promote_model
from modules.drift_detection import detect_drift
from modules.model_registry import registry_path

st.set_page_config(page_title="ModelOps Guardian", page_icon="🛡️", layout="wide")
st.title("🛡️ ModelOps Guardian")
st.caption("End-to-end machine learning lifecycle: validate · train · compare · register · deploy · monitor")

for folder in ["datasets", "models", "artifacts", "reports"]:
    Path(folder).mkdir(exist_ok=True)

page = st.sidebar.radio("Workspace", [
    "Overview", "Dataset & Training", "Model Registry", "Drift Monitoring", "Deployment"
])

if page == "Overview":
    st.subheader("Platform overview")
    registry = load_registry()
    c1, c2, c3 = st.columns(3)
    c1.metric("Registered models", len(registry))
    c2.metric("Production models", sum(x.get("stage") == "Production" for x in registry))
    c3.metric("Experiments", len(list(Path("artifacts").glob("run_*"))))
    st.info("Start by uploading a CSV dataset in Dataset & Training. Select the target column and run the pipeline.")
    st.markdown("""
    **Lifecycle**
    1. Upload and validate a dataset
    2. Train Logistic Regression and Random Forest
    3. Compare metrics and track the experiment
    4. Register a versioned model
    5. Promote an approved model to Production
    6. Compare reference data with new production data for drift
    """)

elif page == "Dataset & Training":
    st.subheader("Dataset ingestion and model training")
    uploaded = st.file_uploader("Upload a CSV dataset", type=["csv"])
    if uploaded:
        df = pd.read_csv(uploaded)
        st.write("Preview", df.head(10))
        st.write(f"Rows: {len(df):,} · Columns: {len(df.columns)}")
        target = st.selectbox("Select target column", list(df.columns))
        if st.button("Validate and train models", type="primary"):
            with st.spinner("Validating data and training models..."):
                try:
                    result = run_experiment(df, target, uploaded.name)
                    st.success("Experiment completed.")
                    st.dataframe(pd.DataFrame(result["metrics"]).T)
                    st.write("Best model:", result["best_model"])
                    st.write("Registered version:", result["model_id"])
                    st.session_state["reference_df"] = df.drop(columns=[target]).copy()
                except Exception as e:
                    st.error(f"Pipeline failed: {e}")
                    st.exception(e)
    else:
        st.caption("For a quick test, use a classification CSV with a target column. Numeric and categorical features are supported.")

elif page == "Model Registry":
    st.subheader("Model registry")
    registry = load_registry()
    if not registry:
        st.warning("No models registered yet. Train a model first.")
    else:
        st.dataframe(pd.DataFrame(registry))
        options = [x["model_id"] for x in registry]
        chosen = st.selectbox("Choose model version to promote", options)
        if st.button("Promote selected model to Production"):
            promote_model(chosen)
            st.success(f"{chosen} promoted to Production.")
            st.rerun()

elif page == "Drift Monitoring":
    st.subheader("Production data drift")
    registry = load_registry()
    if not registry:
        st.warning("Train a model first so a reference dataset is available.")
    else:
        ref_file = Path("datasets/reference_features.csv")
        if not ref_file.exists():
            st.warning("No reference feature data found yet. Train a model first.")
        else:
            reference = pd.read_csv(ref_file)
            incoming = st.file_uploader("Upload new production feature data (CSV; same feature columns)", type=["csv"])
            if incoming:
                current = pd.read_csv(incoming)
                if st.button("Run drift check"):
                    report = detect_drift(reference, current)
                    st.metric("Drifted columns", f'{report["drifted_columns"]} / {report["checked_columns"]}')
                    st.dataframe(pd.DataFrame(report["details"]))
                    if report["drifted_columns"]:
                        st.warning("Distribution changes detected. This is a drift signal, not proof of reduced model accuracy.")
                        st.caption("Retraining should be evaluated using newly labelled outcomes before promotion.")
                    else:
                        st.success("No drift signal detected by the configured checks.")

elif page == "Deployment":
    st.subheader("Prediction API")
    st.markdown("""
    Start the API from a terminal in the project folder:

    ```powershell
    .venv\\Scripts\\activate
    uvicorn api.main:app --reload
    ```

    Then open [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs).
    """)
    registry = load_registry()
    production = [x for x in registry if x.get("stage") == "Production"]
    if production:
        st.success(f'Production model: {production[-1]["model_id"]}')
    else:
        st.info("No model is currently marked as Production. Promote one in Model Registry.")
