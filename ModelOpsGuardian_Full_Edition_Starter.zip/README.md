# ModelOps Guardian

An end-to-end MLOps starter platform for dataset validation, model training, experiment tracking, model registration, deployment, and drift monitoring.

## Windows setup (PowerShell)

1. Install Python 3.11 (64-bit) and Git.
2. Open PowerShell in this folder.
3. Create and activate a virtual environment:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
```

If script execution is blocked, run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

4. Install dependencies:

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

5. Start the dashboard:

```powershell
streamlit run app.py
```

6. In a second PowerShell window, activate the same environment and start the API:

```powershell
.\.venv\Scripts\Activate.ps1
uvicorn api.main:app --reload
```

- Dashboard: http://localhost:8501
- API docs: http://127.0.0.1:8000/docs
- API health: http://127.0.0.1:8000/health

## First test

Use a labelled classification CSV. Upload it under Dataset & Training, select the target column, and run training. The app trains Logistic Regression and Random Forest, records metrics in MLflow, saves the best model, and registers it. Promote the model in Model Registry before calling `/predict`.

## Example prediction request

Send a POST request to `/predict`:

```json
{
  "features": {
    "feature_a": 1.2,
    "feature_b": "category"
  }
}
```

Replace the example keys and values with the exact feature columns and compatible values from your dataset.

## Important scope notes

- This is a functional foundation, not a fully hardened production service.
- The starter pipeline supports classification. Regression, authentication, role-based approvals, remote object storage, CI/CD deployment, and advanced monitoring are planned extensions.
- Drift is a statistical signal about changed input distributions; it does not prove that predictive accuracy has fallen. Validate with labelled outcomes before promoting a retrained model.
- Do not expose the API publicly without authentication, input validation, secrets management, and deployment hardening.

## Team workflow

Use one shared GitHub repository. Assign one owner per module and integrate through pull requests. Do not have multiple people edit the same file simultaneously.
