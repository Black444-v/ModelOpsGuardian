from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from pathlib import Path
import joblib
from modules.model_registry import load_registry

app = FastAPI(title="ModelOps Guardian Prediction API", version="1.0.0")

class PredictionRequest(BaseModel):
    features: dict

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/models")
def models():
    return load_registry()

@app.post("/predict")
def predict(request: PredictionRequest):
    production = [m for m in load_registry() if m.get("stage") == "Production"]
    if not production:
        raise HTTPException(status_code=409, detail="No production model. Promote a model in the dashboard.")
    model_info = production[-1]
    path = Path(model_info["model_path"])
    if not path.exists():
        raise HTTPException(status_code=500, detail="Registered model file is missing.")
    model = joblib.load(path)
    try:
        import pandas as pd
        row = pd.DataFrame([request.features])
        prediction = model.predict(row)[0]
        return {"model_id": model_info["model_id"], "prediction": str(prediction)}
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Prediction failed: {e}")
