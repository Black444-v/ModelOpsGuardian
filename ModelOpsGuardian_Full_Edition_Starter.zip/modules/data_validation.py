import pandas as pd

def validate_dataset(df, target):
    issues = []
    if df.empty:
        issues.append("Dataset is empty.")
    if target not in df.columns:
        issues.append("Target column is missing.")
    if len(df.columns) < 2:
        issues.append("At least one feature and one target column are required.")
    if df.isna().all().any():
        issues.append("At least one column contains only missing values.")
    if target in df.columns and df[target].nunique(dropna=True) < 2:
        issues.append("Target must contain at least two distinct classes for classification.")
    if target in df.columns and df[target].isna().any():
        issues.append("Target contains missing values. Remove or resolve these rows.")
    return issues
