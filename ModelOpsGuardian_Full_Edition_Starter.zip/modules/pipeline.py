import json, uuid, time
from pathlib import Path
import joblib
import pandas as pd
import mlflow
import mlflow.sklearn
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from modules.data_validation import validate_dataset
from modules.model_registry import register_model, load_registry

def run_experiment(df, target, filename="uploaded.csv"):
    issues = validate_dataset(df, target)
    if issues:
        raise ValueError("Data validation failed: " + " ".join(issues))
    data = df.dropna(subset=[target]).copy()
    X, y = data.drop(columns=[target]), data[target]
    if y.nunique() > 30:
        raise ValueError("This starter edition supports classification targets with up to 30 classes.")
    numeric = X.select_dtypes(include=["number"]).columns.tolist()
    categorical = [c for c in X.columns if c not in numeric]
    transformers = []
    if numeric:
        transformers.append(("num", Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler())
        ]), numeric))
    if categorical:
        transformers.append(("cat", Pipeline([
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore"))
        ]), categorical))
    preprocessor = ColumnTransformer(transformers)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42,
        stratify=y if y.value_counts().min() >= 2 else None
    )
    candidates = {
        "LogisticRegression": LogisticRegression(max_iter=1000),
        "RandomForest": RandomForestClassifier(n_estimators=150, random_state=42)
    }
    metrics, fitted = {}, {}
    mlflow.set_tracking_uri("file:./mlruns")
    mlflow.set_experiment("ModelOps-Guardian")
    for name, estimator in candidates.items():
        pipe = Pipeline([("preprocess", preprocessor), ("model", estimator)])
        started = time.time()
        pipe.fit(X_train, y_train)
        predictions = pipe.predict(X_test)
        scores = {
            "accuracy": float(accuracy_score(y_test, predictions)),
            "precision_weighted": float(precision_score(y_test, predictions, average="weighted", zero_division=0)),
            "recall_weighted": float(recall_score(y_test, predictions, average="weighted", zero_division=0)),
            "f1_weighted": float(f1_score(y_test, predictions, average="weighted", zero_division=0)),
            "training_seconds": round(time.time() - started, 3)
        }
        with mlflow.start_run(run_name=name):
            mlflow.log_params({"model": name, "dataset": filename, "target": target})
            mlflow.log_metrics(scores)
            mlflow.sklearn.log_model(pipe, artifact_path="model")
        metrics[name] = scores
        fitted[name] = pipe
    best_name = max(metrics, key=lambda n: metrics[n]["f1_weighted"])
    model_id = f"{best_name.lower()}-{uuid.uuid4().hex[:8]}"
    model_path = Path("models") / f"{model_id}.joblib"
    joblib.dump(fitted[best_name], model_path)
    Path("datasets").mkdir(exist_ok=True)
    X.to_csv("datasets/reference_features.csv", index=False)
    register_model(model_id, model_path, best_name, metrics[best_name], target, list(X.columns))
    run_dir = Path("artifacts") / f"run_{model_id}"
    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    return {"metrics": metrics, "best_model": best_name, "model_id": model_id}

def load_registry():
    from modules.model_registry import load_registry as _load
    return _load()
