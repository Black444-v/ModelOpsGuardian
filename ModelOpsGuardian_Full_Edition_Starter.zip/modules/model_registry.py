import json
from pathlib import Path
from datetime import datetime, timezone

REGISTRY = Path("artifacts/model_registry.json")
MODEL_DIR = Path("models")
REGISTRY.parent.mkdir(exist_ok=True)
MODEL_DIR.mkdir(exist_ok=True)

def load_registry():
    if not REGISTRY.exists():
        return []
    return json.loads(REGISTRY.read_text(encoding="utf-8"))

def save_registry(items):
    REGISTRY.write_text(json.dumps(items, indent=2), encoding="utf-8")

def register_model(model_id, model_path, model_name, metrics, target, features):
    items = load_registry()
    items.append({
        "model_id": model_id,
        "model_name": model_name,
        "model_path": str(model_path),
        "metrics": metrics,
        "target": target,
        "features": features,
        "stage": "Staging",
        "created_at": datetime.now(timezone.utc).isoformat()
    })
    save_registry(items)

def promote_model(model_id):
    items = load_registry()
    found = False
    for item in items:
        if item["model_id"] == model_id:
            item["stage"] = "Production"
            found = True
        elif item["stage"] == "Production":
            item["stage"] = "Archived"
    if not found:
        raise ValueError("Unknown model id")
    save_registry(items)

registry_path = REGISTRY
