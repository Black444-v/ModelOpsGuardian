import pandas as pd
from scipy.stats import ks_2samp, chi2_contingency
import numpy as np

def detect_drift(reference, current, p_threshold=0.05):
    details = []
    shared = [c for c in reference.columns if c in current.columns]
    for col in shared:
        a, b = reference[col].dropna(), current[col].dropna()
        if len(a) < 2 or len(b) < 2:
            continue
        if pd.api.types.is_numeric_dtype(a) and pd.api.types.is_numeric_dtype(b):
            stat, p = ks_2samp(a, b)
            method = "Kolmogorov-Smirnov"
        else:
            av, bv = a.astype(str).value_counts(), b.astype(str).value_counts()
            categories = sorted(set(av.index) | set(bv.index))
            observed = np.array([[av.get(k, 0) for k in categories],
                                 [bv.get(k, 0) for k in categories]])
            # Avoid invalid chi-square tables with all-zero columns.
            observed = observed[:, observed.sum(axis=0) > 0]
            if observed.shape[1] < 2:
                continue
            stat, p, _, _ = chi2_contingency(observed)
            method = "Chi-square"
        details.append({"column": col, "method": method, "statistic": float(stat),
                        "p_value": float(p), "drift_detected": bool(p < p_threshold)})
    drifted = sum(x["drift_detected"] for x in details)
    return {"checked_columns": len(details), "drifted_columns": drifted, "details": details}
